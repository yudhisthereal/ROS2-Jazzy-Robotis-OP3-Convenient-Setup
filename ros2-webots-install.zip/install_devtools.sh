#!/usr/bin/bash
sudo apt update && sudo apt install ros-dev-tools -y
