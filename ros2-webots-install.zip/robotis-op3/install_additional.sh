#!/usr/bin/bash
sudo apt update
sudo apt install python3-rosdep -y
sudo rosdep init
rosdep udpate
